core
====

zppro's core library