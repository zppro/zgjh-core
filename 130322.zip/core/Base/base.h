//
//  base.h
//  core
//
//  Created by 钟 平 on 12-7-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#ifndef core_base_h
#define core_base_h

#import "BaseController.h"
#import "BaseModel.h"
#import "BaseView.h"


#endif
