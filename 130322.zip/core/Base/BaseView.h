//
//  BaseView.h
//  PonhooLibrary
//
//  Created by 钟 平 on 12-3-30.
//  Copyright (c) 2012年 ponhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseView : UIView

@end
