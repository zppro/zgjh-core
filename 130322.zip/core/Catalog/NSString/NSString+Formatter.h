//
//  NSString+Formatter.h
//  core
//
//  Created by zppro on 13-1-16.
//
//

#import <Foundation/Foundation.h>

@interface NSString (Formatter)
+(NSString*)guidString;

-(NSUInteger) indexOf:(NSString *) subStr;

@end
