//
//  NSArray+ArrayQuery.h
//  DKPredicateBuilder
//
//  Created by Keith Pitt on 29/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DKArrayQuery.h"

@interface NSArray (DKArrayQuery)

- (DKArrayQuery *)query;

- (DKArrayQuery *)queryArray;

@end