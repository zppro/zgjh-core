//
//  CatalogOfUIImage.h
//  core
//
//  Created by zppro on 12-12-4.
//
//

#ifndef core_CatalogOfUIImage_h
#define core_CatalogOfUIImage_h

#import "UIImage+Scale.h"


#endif
